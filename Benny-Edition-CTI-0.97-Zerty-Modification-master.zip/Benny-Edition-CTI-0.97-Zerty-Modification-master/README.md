# Benny-Edition-CTI-0.97-Zerty-Modification

## Monetization
This mission (or code that I own inside) __cannot__ be used in a monetization process as defined by BiS at http://www.bistudio.com/monetization & http://www.bistudio.com/monetization/faq

## Licence

<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">BECTI Zerty Edit.</span> by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Zerty</span> is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.<br />Based on a work at <a xmlns:dct="http://purl.org/dc/terms/" href="http://forums.bistudio.com/showthread.php?166433-SP-MP-BeCTI" rel="dct:source">http://forums.bistudio.com/showthread.php?166433-SP-MP-BeCTI</a>.

This project is not affiliated or authorized by Bohemia Interactive a.s. Bohemia Interactive, ARMA, DAYZ and all associated logos and designs are trademarks or registered trademarks of Bohemia Interactive a.s. 

## Credits:
- *Benny* for the mission
- *Bl1p, Fluit* for random AI skill
- *=ATM=Pokertour* for ATM airdrop
- *Prodavec* for Map Markers titling
- *Farooq* for his original idea of a revive script
- *Sari* for updating the sanitize scripts
- *John681611* for his original idea of offroad aug.
- *Henroth* for his Aircraft loadout customisation framework.
