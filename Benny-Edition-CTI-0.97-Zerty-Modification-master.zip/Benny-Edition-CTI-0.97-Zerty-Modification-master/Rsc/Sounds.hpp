class CfgSounds {
	sounds[] = {prison};
	class prison {
		name = "prison";
		sound[] = {"Rsc\Sounds\prison.ogg", 1, 1.0};
		titles[] = {};
	};	
	class trophy {
		name = "prison";
		sound[] = {"Rsc\Sounds\trophy.ogg", db+10, 1.0};
		titles[] = {};
	};
	class Vent {
		name="Vent";
		sound[]={"Addons\ATM_Airdrop\data\vent.ogg",db-11,1.0};
		titles[] = {};
	};
	class Para {
		name="Para";
		sound[]={"Addons\ATM_Airdrop\data\parachute.ogg",db-11,1.0};
		titles[] = {};
	};
};
