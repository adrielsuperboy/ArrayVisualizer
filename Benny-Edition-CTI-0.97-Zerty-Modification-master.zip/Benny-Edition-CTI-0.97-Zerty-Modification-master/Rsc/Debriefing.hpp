class CfgDebriefing {
	class End1 {
		title = $STR_Mission_Completed;
		subtitle = "";
		description = $STR_End1_dscrp;
		pictureBackground = "";
	};
	class End2 {
		title = $STR_Mission_Failed;
		subtitle = "";
		description = $STR_End2_dscrp;
		pictureBackground = "";
	};
	class End3 {
		title = $STR_Mission_Completed;
		subtitle = "";
		description = $STR_End3_dscrp;
		pictureBackground = "";
	};
	class End4 {
		title = $STR_Mission_Failed;
		subtitle = "";
		description = $STR_End4_dscrp;
		pictureBackground = "";
	};
	class End5 {
		title = $STR_Mission_Failed;
		subtitle = "";
		description = $STR_End5_dscrp;
		pictureBackground = "";
	};
	class End6 {
		title = $STR_End6;
		subtitle = "";
		description = $STR_End6_dscrp;
		pictureBackground = "";
	};
	class End7 {
		title = $STR_End7;
		subtitle = "";
		description = $STR_End7_dscrp;
		pictureBackground = "";
	};
};